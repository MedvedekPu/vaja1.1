import  java.util.ArrayList;
import  java.util.List;
public class Artikli  {


private ArrayList<Artikel>tabela = new ArrayList<>();

public Artikli(List<Artikel> tabela){

    this.tabela = new ArrayList<>();

    }

    public void dodaj(Artikel l)
    {tabela.add(l);
        }

    public ArrayList<Artikel> getTabela() {
        return tabela;
    }

    public void setTabela(ArrayList<Artikel> tabela) {
        this.tabela = tabela;
    }

    @Override
    public String toString() {
        return "Artikli{" +
                "tabela=" + tabela +
                '}';
    }


}
