

public interface Searchable {
    public boolean search(String n);
}
