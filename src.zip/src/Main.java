import com.keepautomation.barcode.BarCode;
import com.keepautomation.barcode.IBarCode;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Main {

    public static void main(String[] args) {
    BarCode  bar = new BarCode();
    BarCode bar2 = new BarCode();


        int vsota=0;
        double DDV = 0.22;
        double DDVvsota =0;
        bar.setCodeToEncode("123456789999");
        bar.setSymbology(IBarCode.EAN13);
        bar.setX(2);
        bar.setY(50);
        bar.setRightMargin(0);
        bar.setLeftMargin(0);
        bar.setTopMargin(0);
        bar.setBottomMargin(0);

        try
        {

            bar.draw("C:\\Fax\\Prog_jeziki_2019\\ean13.gif");

        }
        catch (Exception e) {
            e.printStackTrace();
        }









        UUID uuid = UUID.randomUUID();
        String randUUIDString = uuid.toString();
        List<Artikel> seznam = new ArrayList<>();
        seznam.add(new Artikel(250,"pepsi",1,bar));
        seznam.add(new Artikel(300,"fanta",2,bar2));
        seznam.add(new Artikel(100,"sprite",3,bar));
        seznam.add(new Artikel(100,"sok",2,bar));

        for(Artikel pr:seznam)
        {
            vsota+= pr.getCena()* pr.getKolicina();
            DDVvsota+= pr.getCena() * pr.getKolicina() +DDV;

        }

        Date datum = new Date();
        Artikli test1 = new Artikli(seznam);
        test1.dodaj(new Artikel(2,"pivo",1,bar));

        //Racun test = new Racun(randUUIDString,test1,datum,);
        System.out.println( seznam);

        System.out.println("Skupna cena: " + vsota + "skupna cena z ddv-jem: " + DDVvsota);
        //System.out.println(test);
        //System.out.println(test);
        System.out.println("uuid" + randUUIDString);


     //2naloga

        Podjetje p1 = new Podjetje("Henkel",58665765,6261752000L,true);
        Podjetje p2 = new Podjetje("Energija Plus",88157598,3991008000L,true);
        Podjetje p3 = new Podjetje("Snaga",30543517,5015545000L,false);
        System.out.println(p1);


        Racun noviRacun = new Racun(randUUIDString,test1,datum,p1);
        System.out.println(noviRacun);




    }


    /**
     *
     * Ali za znesek uporabiti int ali double?
     * int
     * Kaj je ID? kako ga implementirati?
     *
     * Kaj je EAN koda?
     * Ali je primerna za primarni ključ? Da
     *
     */
}
