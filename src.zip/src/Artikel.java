import com.keepautomation.barcode.BarCode;

import java.util.UUID;


public class Artikel implements Searchable {
    private int Cena;
    private int Kolicina;
    private  String Ime;
    BarCode barcode; // ean koda



    public String getIme(){
        return Ime;
    }
    public void setIme(String ime){
        Ime = ime;
    }

    public int getCena(){
        return Cena;
    }
    public void setCena(int Cena){

        Cena = Cena;
    }

    public void setBarcode(BarCode barcode) {

        this.barcode = barcode;
    }

    public double getKolicina(){return Kolicina;}

    public void setKolicina(double Kolicina){
        Kolicina = Kolicina;
    }


    public Artikel(int Cena,String ime, int Kolicina, BarCode barcode) {


        this.Cena = Cena;
        this.Ime = ime;
        this.Kolicina=Kolicina;
        this.barcode= barcode;

    }

    @Override
    public String toString() {
        return "\n"+"Artikel{" +
                "Cena=" + Cena +
                ", Kolicina=" + Kolicina +
                ", Ime='" + Ime + '\''+ "Barkoda= " + barcode +
                '}';
    }

    @Override
    public boolean search(String n) {
        if(n==getIme())
            return false;

        return false;
    }

    static  boolean checkDigit(BarCode barcode){



        return true;
    }

}

